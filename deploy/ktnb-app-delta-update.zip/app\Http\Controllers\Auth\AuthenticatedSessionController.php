<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Services\ActivityLogService;
use App\Services\SettingsSecurityService;
use App\Services\SystemParameterService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class AuthenticatedSessionController extends Controller
{
    /**
     * Display the login view.
     */
    public function create(): View
    {
        $params = app(SystemParameterService::class)->forLoginPage();

        return view('auth.login', [
            'bannerUrl' => $params['bannerUrl'],
            'loginImageUrl' => $params['loginImageUrl'],
            'loginQuote' => $params['loginQuote'],
            'loginQuoteAuthor' => $params['loginQuoteAuthor'],
        ]);
    }

    /**
     * Handle an incoming authentication request.
     */
    public function store(LoginRequest $request): RedirectResponse
    {
        $request->authenticate();

        $request->session()->regenerate();

        $user = $request->user();
        if ($user) {
            app(ActivityLogService::class)->logDeferred(
                'LOGIN',
                'Auth',
                $user->name.' đã đăng nhập vào hệ thống. '
                    .app(SettingsSecurityService::class)->parseUserAgent($request->userAgent()),
                $user,
            );
        }

        if ($user?->must_change_password) {
            return redirect()->route('password.force');
        }

        return redirect()->intended(route('dashboard', absolute: false));
    }

    /**
     * Destroy an authenticated session.
     */
    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }
}
