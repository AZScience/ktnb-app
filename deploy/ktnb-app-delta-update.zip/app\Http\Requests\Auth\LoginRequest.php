<?php

namespace App\Http\Requests\Auth;

use App\Services\AuthLoginService;
use Illuminate\Auth\Events\Lockout;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class LoginRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'email' => ['nullable', 'string', 'email'],
            'password' => ['nullable', 'string'],
        ];
    }

    protected function prepareForValidation(): void
    {
        $defaults = config('nttu.login_defaults', []);
        $defaultEmail = strtolower(trim((string) ($defaults['email'] ?? 'ntt-00000@ntt.edu.vn')));
        $defaultPassword = (string) ($defaults['password'] ?? 'NTT-00000');

        $email = strtolower(trim((string) $this->input('email', '')));
        $password = (string) $this->input('password', '');

        $this->merge([
            'email' => $email !== '' ? $email : $defaultEmail,
            'password' => trim($password) !== '' ? $password : $defaultPassword,
        ]);
    }

    /**
     * Attempt to authenticate the request's credentials.
     *
     * @throws ValidationException
     */
    public function authenticate(): void
    {
        $this->ensureIsNotRateLimited();

        try {
            app(AuthLoginService::class)->attempt(
                $this->string('email')->toString(),
                $this->string('password')->toString(),
                $this->boolean('remember'),
            );
        } catch (ValidationException $exception) {
            RateLimiter::hit($this->throttleKey());

            throw $exception;
        }

        RateLimiter::clear($this->throttleKey());
    }

    /**
     * Ensure the login request is not rate limited.
     *
     * @throws ValidationException
     */
    public function ensureIsNotRateLimited(): void
    {
        if (! RateLimiter::tooManyAttempts($this->throttleKey(), 5)) {
            return;
        }

        event(new Lockout($this));

        $seconds = RateLimiter::availableIn($this->throttleKey());

        throw ValidationException::withMessages([
            'email' => trans('auth.throttle', [
                'seconds' => $seconds,
                'minutes' => ceil($seconds / 60),
            ]),
        ]);
    }

    /**
     * Get the rate limiting throttle key for the request.
     */
    public function throttleKey(): string
    {
        return Str::transliterate(Str::lower($this->string('email')).'|'.$this->ip());
    }
}
