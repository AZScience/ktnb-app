<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('document_records', function (Blueprint $table) {
            $table->foreignId('created_by_user_id')->nullable()->after('file_password')->constrained('users')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('document_records', function (Blueprint $table) {
            $table->dropConstrainedForeignId('created_by_user_id');
        });
    }
};
