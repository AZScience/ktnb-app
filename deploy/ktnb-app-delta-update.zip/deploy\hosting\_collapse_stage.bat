@echo off
cd /d "d:\ktnb-app\deploy"
if exist "_collapse_tmp" rmdir /s /q "_collapse_tmp" 2>nul

set /a n=0
:loop
if not exist "_stage_ktnb" goto done
set /a n+=1

if exist "_stage_ktnb\deploy\_stage_ktnb" (
  move /Y "_stage_ktnb\deploy\_stage_ktnb" "_collapse_tmp" >nul
  if errorlevel 1 (
    echo MOVE_FAIL pass=%n%
    exit /b 1
  )
  rmdir /s /q "_stage_ktnb" 2>nul
  move /Y "_collapse_tmp" "_stage_ktnb" >nul
  if errorlevel 1 (
    echo RENAME_FAIL pass=%n%
    exit /b 1
  )
  if "%n%"=="10" echo collapsed=%n%
  if "%n%"=="50" echo collapsed=%n%
  if "%n%"=="100" echo collapsed=%n%
  if "%n%"=="200" echo collapsed=%n%
  if "%n%"=="500" echo collapsed=%n%
  goto loop
)

echo Final delete pass=%n%
rmdir /s /q "_stage_ktnb"
if exist "_stage_ktnb" (
  echo STILL_FAIL
  exit /b 1
)

:done
echo STAGE_GONE passes=%n%
exit /b 0
