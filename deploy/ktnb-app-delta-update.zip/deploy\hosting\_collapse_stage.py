import os
import shutil
import time

base = r"D:\ktnb-app\deploy"
stage = os.path.join(base, "_stage_ktnb")
tmp = os.path.join(base, "_collapse_tmp")

def exists(p: str) -> bool:
    return os.path.exists(p) or os.path.exists("\\\\?\\" + p)


def rm_tree(p: str) -> None:
    # Prefer long-path rmtree; fall back to cascade
    for candidate in (p, "\\\\?\\" + p):
        if os.path.exists(candidate):
            shutil.rmtree(candidate, ignore_errors=True)
    # if still there, ignore — next collapse pass may help


t0 = time.time()
passes = 0
while exists(stage):
    nested = os.path.join(stage, "deploy", "_stage_ktnb")
    if exists(tmp):
        rm_tree(tmp)

    if exists(nested):
        # Pull nested one level out, drop the outer shell.
        os.replace(nested, tmp)
        rm_tree(stage)
        os.replace(tmp, stage)
        passes += 1
        if passes % 10 == 0:
            print(f"collapsed={passes}", flush=True)
        continue

    # No deeper nest — delete remaining shell
    rm_tree(stage)
    break

print("DONE exists=", exists(stage), "passes=", passes, "sec=", round(time.time() - t0, 1))
