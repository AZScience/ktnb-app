@echo off
setlocal
cd /d "d:\ktnb-app\deploy"
for /L %%i in (1,1,30) do (
  if not exist "_stage_ktnb" goto done
  call "d:\ktnb-app\deploy\hosting\_collapse_stage.bat"
  if not exist "_stage_ktnb" goto done
)
if exist "_stage_ktnb" (
  echo STILL_AFTER_RETRIES
  exit /b 1
)
:done
echo ALL_GONE
exit /b 0
