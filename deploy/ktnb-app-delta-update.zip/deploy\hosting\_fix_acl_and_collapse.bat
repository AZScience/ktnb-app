@echo off
cd /d "d:\ktnb-app\deploy"
icacls "_stage_ktnb" /grant "%USERNAME%:(OI)(CI)F" /T /C /Q
if errorlevel 1 echo ICACLS_WARN
ren "_stage_ktnb\deploy\_stage_ktnb" zzz
if errorlevel 1 (
  echo REN_FAIL
  exit /b 1
)
echo REN_OK
call "d:\ktnb-app\deploy\hosting\_collapse_until_gone.bat"
