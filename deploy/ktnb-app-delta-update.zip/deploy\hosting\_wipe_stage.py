import os
import time

root = r"\\?\D:\ktnb-app\deploy\_stage_ktnb"

def wipe(path: str) -> None:
    if not os.path.exists(path):
        print("already_gone")
        return
    # Repeated passes: remove files then dirs deepest-ish via listdir recursion
    def clear(p: str) -> None:
        try:
            entries = os.listdir(p)
        except Exception as e:
            print("listdir_fail", p[-80:], e)
            return
        for name in entries:
            child = p + "\\" + name
            try:
                if os.path.isdir(child) and not os.path.islink(child):
                    clear(child)
                    try:
                        os.rmdir(child)
                    except Exception:
                        pass
                else:
                    try:
                        os.chmod(child, 0o777)
                    except Exception:
                        pass
                    try:
                        os.remove(child)
                    except Exception:
                        pass
            except Exception as e:
                print("child_fail", name, e)

    t0 = time.time()
    clear(root)
    try:
        os.rmdir(root)
    except Exception as e:
        print("root_rmdir", e)
    print("DONE exists=", os.path.exists(root), "sec=", round(time.time() - t0, 1))

wipe(root)
